from setuptools import setup

setup(
    name="paqueteModulosYPaquetes",
    version="0.1",
    description="Ejercicio número 9 del tema de módulos y paquetes",
    author="Guillermo Castro García",
    author_email="guicasgar@gmail.com",
    packages=["GuillermoCastroGarciaT9"],
    scripts=[]
)